<?php

namespace ClassyHD;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\Server;
use pocketmine\form\Form;

class Hediye extends PluginBase {

    public function onEnable(): void {
        $this->getLogger()->info("§aHediye eklentisi yüklendi!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cBu komutu sadece oyunda kullanabilirsin.");
            return true;
        }

        if ($command->getName() === "hediye") {
            $this->showHediyeForm($sender);
            return true;
        }

        return false;
    }

    public function showHediyeForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage("§cElinde hediye edecek bir eşya yok!");
            return;
        }

        $form = new class($player, $item) implements Form {
            private Player $player;
            private Item $item;

            public function __construct(Player $player, Item $item) {
                $this->player = $player;
                $this->item = $item;
            }

            public function jsonSerialize(): mixed {
                return [
                    "type" => "custom_form",
                    "title" => "Hediye Gönder",
                    "content" => [
                        [
                            "type" => "input",
                            "text" => "§bHangi oyuncuya hediye vermek istersin?",
                            "placeholder" => "Oyuncu adı"
                        ],
                        [
                            "type" => "input",
                            "text" => "Hediye notu (isteğe bağlı)",
                            "placeholder" => "Mesaj yaz..."
                        ],
                        [
                            "type" => "label",
                            "text" => "Gönderilecek eşya: §a" . $this->item->getName() . " x" . $this->item->getCount()
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) {
                    $player->sendMessage("§cHediye gönderme iptal edildi.");
                    return;
                }

                $hedefAd = trim($data[0]);
                $not = $data[1] ?? "";

                $target = Server::getInstance()->getPlayerExact($hedefAd);

                if ($target === null || !$target->isOnline()) {
                    $player->sendMessage("§cOyuncu bulunamadı: §f{$hedefAd}");
                    return;
                }

                if ($this->item->isNull()) {
                    $player->sendMessage("§cGönderilecek eşya bulunamadı.");
                    return;
                }

                // Eşyayı gönder
                $player->getInventory()->removeItem($this->item);
                $target->getInventory()->addItem($this->item);

                $player->sendMessage("§f{$target->getName()} §aadlı oyuncuya hediye gönderdin!");
                $target->sendMessage("§f{$player->getName()} §bsana bir hediye gönderdi!");

                if ($not !== "") {
                    $target->sendMessage("§7Not: §f" . $not);
                }
            }
        };

        $player->sendForm($form);
    }
}